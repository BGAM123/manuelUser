<?php

namespace App\Repository;

use App\Entity\PieceJointe;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<PieceJointe>
 */
class PieceJointeRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, PieceJointe::class);
    }

    public function save(PieceJointe $pieceJointe, bool $flush = true): void
    {
        $this->getEntityManager()->persist($pieceJointe);
        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }
}
