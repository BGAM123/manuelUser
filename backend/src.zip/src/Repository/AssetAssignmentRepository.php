<?php

namespace App\Repository;

use App\Entity\AssetAssignment;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<AssetAssignment>
 */
class AssetAssignmentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, AssetAssignment::class);
    }

    public function save(AssetAssignment $assignment): void
    {
        $this->getEntityManager()->persist($assignment);
        $this->getEntityManager()->flush();
    }

    public function remove(AssetAssignment $assignment): void
    {
        $this->getEntityManager()->remove($assignment);
        $this->getEntityManager()->flush();
    }

    /**
     * @return AssetAssignment[]
     */
    public function findByAsset(int $assetId): array
    {
        return $this->createQueryBuilder('a')
            ->leftJoin('a.user', 'u')
            ->addSelect('u')
            ->leftJoin('a.service', 's')
            ->addSelect('s')
            ->where('a.asset = :assetId')
            ->andWhere('a.isDelete = false')
            ->setParameter('assetId', $assetId)
            ->orderBy('a.dateDebut', 'DESC')
            ->getQuery()
            ->getResult();
    }

    /**
     * @return AssetAssignment|null
     */
    public function findActiveByAsset(int $assetId): ?AssetAssignment
    {
        return $this->createQueryBuilder('a')
            ->leftJoin('a.user', 'u')
            ->addSelect('u')
            ->leftJoin('a.service', 's')
            ->addSelect('s')
            ->where('a.asset = :assetId')
            ->andWhere('a.isDelete = false')
            ->andWhere('a.dateFin IS NULL')
            ->setParameter('assetId', $assetId)
            ->orderBy('a.dateDebut', 'DESC')
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * @return AssetAssignment[]
     */
    public function findActiveByUser(int $userId): array
    {
        return $this->createQueryBuilder('a')
            ->leftJoin('a.asset', 'asset')
            ->addSelect('asset')
            ->leftJoin('a.service', 's')
            ->addSelect('s')
            ->where('a.user = :userId')
            ->andWhere('a.isDelete = false')
            ->andWhere('a.dateFin IS NULL')
            ->setParameter('userId', $userId)
            ->getQuery()
            ->getResult();
    }

    /**
     * @return AssetAssignment|null
     */
    public function findLastActiveByAssetId(int $assetId): ?AssetAssignment
    {
        return $this->createQueryBuilder('a')
            ->leftJoin('a.user', 'u')
            ->addSelect('u')
            ->leftJoin('a.service', 's')
            ->addSelect('s')
            ->where('a.asset = :assetId')
            ->andWhere('a.isDelete = false')
            ->setParameter('assetId', $assetId)
            ->orderBy('a.createdAt', 'DESC')
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();
    }
}
