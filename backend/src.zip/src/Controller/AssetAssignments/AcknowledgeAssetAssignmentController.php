<?php

namespace App\Controller\AssetAssignments;

use App\Entity\AssetAssignment;
use App\Entity\Notification;
use App\Entity\User;
use App\Exception\ResourceNotFoundException;
use App\Exception\ValidationFailedException;
use App\Repository\AssetAssignmentRepository;
use App\Service\AcknowledgementService;
use App\Service\ApiResponseFactory;
use App\Service\AssetAssignmentResponseBuilder;
use App\Service\AssetAssignmentService;
use OpenApi\Attributes as OA;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\CurrentUser;

#[Route('/asset-assignments')]
#[OA\Tag(name: 'Asset Assignments')]
final class AcknowledgeAssetAssignmentController extends AbstractController
{
    #[Route('/{id}/acknowledge', name: 'app_asset_assignment_acknowledge', methods: ['POST'])]
    #[OA\Post(
        path: '/asset-assignments/{id}/acknowledge',
        summary: 'Accuser réception d\'une affectation de bien',
        description: "Réservé au destinataire de l'affectation. Ne peut être fait qu'une seule fois par affectation."
    )]
    #[OA\Parameter(name: 'id', in: 'path', required: true, schema: new OA\Schema(type: 'integer'), example: 1)]
    #[OA\Response(response: 200, description: 'Accusé de réception enregistré')]
    #[OA\Response(response: 400, description: 'Déjà accusé réception', content: new OA\JsonContent(example: ['success' => false, 'status' => 400, 'message' => 'Un accusé de réception a déjà été enregistré pour cette transaction.', 'data' => ['acknowledgement' => 'Un accusé de réception a déjà été enregistré pour cette transaction.']]))]
    #[OA\Response(response: 403, description: 'Utilisateur non autorisé (pas le destinataire)')]
    #[OA\Response(response: 404, description: 'Affectation introuvable')]
    public function __invoke(
        int $id,
        Request $request,
        #[CurrentUser] User $user,
        AssetAssignmentRepository $assignmentRepository,
        AssetAssignmentService $assignmentService,
        AcknowledgementService $acknowledgementService,
        AssetAssignmentResponseBuilder $responseBuilder,
        ApiResponseFactory $apiResponse
    ): JsonResponse {
        $assignment = $assignmentRepository->find($id);
        if (!$assignment instanceof AssetAssignment || $assignment->isDelete()) {
            throw new ResourceNotFoundException("L'affectation demandée est introuvable.");
        }

        $recipient = $assignmentService->resolveRecipient($assignment);
        if (!$recipient || $recipient->getId() !== $user->getId()) {
            throw new AccessDeniedHttpException("Vous n'êtes pas autorisé à accuser réception de cette affectation.");
        }

        $comment = $request->request->get('commentaire');

        try {
            $acknowledgementService->acknowledge($user, Notification::SUBJECT_ASSET_ASSIGNMENT, $assignment->getId(), $comment);
        } catch (ValidationFailedException $e) {
            return $apiResponse->error($e->getMessage(), Response::HTTP_BAD_REQUEST, $e->getErrors());
        }

        return $apiResponse->success(
            $responseBuilder->buildDetail($assignment),
            Response::HTTP_OK,
            'Accusé de réception enregistré avec succès.'
        );
    }
}
