<?php

namespace App\Controller\Roles;

use App\Repository\RoleRepository;
use App\Service\ApiResponseFactory;
use OpenApi\Attributes as OA;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;

#[Route('/roles')]
#[OA\Tag(name: 'Roles')]
final class CreateRoleController extends AbstractController
{
    #[Route('', name: 'app_role_create', methods: ['POST'])]
    #[OA\Post(path: '/roles', summary: 'Créer un rôle', description: 'Crée un nouveau rôle avec éventuellement des permissions associées.')]
    #[OA\RequestBody(
        required: true,
        content: new OA\JsonContent(
            type: 'object',
            required: ['nom'],
            properties: [
                new OA\Property(property: 'nom', type: 'string', example: 'Gestionnaire de Biens'),
                new OA\Property(property: 'description', type: 'string', example: 'Gère les biens du patrimoine au quotidien'),
                new OA\Property(property: 'is_active', type: 'boolean', example: true),
                new OA\Property(property: 'permissions', type: 'array', items: new OA\Items(type: 'integer'), example: [1, 2, 3], description: 'Liste optionnelle des IDs de permissions à affecter au rôle')
            ]
        )
    )]
    #[OA\Response(
        response: 201,
        description: 'Created - Rôle créé avec succès',
        content: new OA\JsonContent(
            example: [
                'success' => true,
                'status' => 201,
                'message' => 'Rôle créé avec succès.',
                'data' => ['id' => 7, 'nom' => 'Auditeur', 'description' => 'Consultation à des fins de contrôle', 'is_active' => true]
            ]
        )
    )]
    #[OA\Response(response: 400, description: 'Bad Request - Payload invalide')]
    #[OA\Response(response: 409, description: 'Conflict - Ce nom de rôle existe déjà')]
    public function __invoke(
        Request $request,
        RoleRepository $roleRepository,
        SerializerInterface $serializer,
        ValidatorInterface $validator,
        ApiResponseFactory $apiResponse
    ): JsonResponse {
        $payload = json_decode($request->getContent(), true);
        if (!is_array($payload)) {
            return $apiResponse->error('Charge JSON invalide.', Response::HTTP_BAD_REQUEST);
        }

        if (!empty($payload['nom']) && $roleRepository->existsByNom((string) $payload['nom'])) {
            return $apiResponse->error('Ce nom de rôle est déjà utilisé.', Response::HTTP_CONFLICT);
        }

        try {
            $role = $roleRepository->buildRoleFromPayload($payload);
        } catch (\InvalidArgumentException $e) {
            return $apiResponse->error($e->getMessage(), Response::HTTP_BAD_REQUEST);
        }

        $errors = $validator->validate($role);
        if (count($errors) > 0) {
            $errorsData = json_decode($serializer->serialize($errors, 'json'), true);
            return $apiResponse->error('La validation a échoué.', Response::HTTP_BAD_REQUEST, $errorsData);
        }

        $roleRepository->save($role);

        $data = json_decode($serializer->serialize($role, 'json', ['groups' => ['role:detail']]), true);
        return $apiResponse->success($data, Response::HTTP_CREATED, 'Rôle créé avec succès.');
    }
}
